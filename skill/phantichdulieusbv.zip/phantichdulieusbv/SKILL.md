---
name: phantichdulieusbv
description: >
  Phân tích dữ liệu kinh tế vĩ mô từ file Excel và lập báo cáo .docx theo mẫu Word. Đọc mẫu báo cáo .docx để xác định cấu trúc, đọc file .xlsx chứa dữ liệu World Bank, dùng code Python tham chiếu (lưu sẵn) để vẽ biểu đồ matplotlib/seaborn, thống kê mô tả, tương quan, huấn luyện LinearRegression, dự báo GDP, điền kết quả vào báo cáo giữ nguyên định dạng gốc. KÍCH HOẠT khi tải lên file .docx + .xlsx và yêu cầu: "dùng skill phantichdulieusbv", "phân tích dữ liệu và lập báo cáo", "tạo báo cáo kinh tế vĩ mô", "điền báo cáo từ dữ liệu Excel", "phân tích dữ liệu sbv", "báo cáo vĩ mô", "biểu đồ GDP", "dự báo GDP", hoặc khi có file Excel + Word cần phân tích kinh tế.
---

# Skill: Phân tích dữ liệu SBV (phantichdulieusbv)

Tự động phân tích dữ liệu kinh tế vĩ mô và lập báo cáo hoàn chỉnh từ file Excel + mẫu Word.

---

## FILE THAM CHIẾU TRONG SKILL

Skill chứa sẵn file Python tham chiếu:
```
<skill_dir>/reference_code.py
```
File này chứa tất cả logic code gốc: cách vẽ biểu đồ (matplotlib, seaborn), cách huấn
luyện mô hình (LinearRegression, train_test_split), cách đánh giá (MSE, RMSE, MAE), và
cách dự báo (model.predict). Claude sẽ đọc file này để áp dụng đúng style và logic.

---

## QUY TRÌNH THỰC HIỆN (7 BƯỚC)

### BƯỚC 0 — ĐỌC CÁC FILE KỸ NĂNG CỐT LÕI (BẮT BUỘC)

```
1. Đọc /mnt/skills/public/docx/SKILL.md        ← hướng dẫn tạo/chỉnh file .docx
2. Đọc <skill_dir>/reference_code.py            ← code Python tham chiếu
```

**PHẢI đọc cả 2 file trước khi bắt đầu.**

---

### BƯỚC 1 — NHẬN DIỆN FILE ĐẦU VÀO

Người dùng tải lên 2 loại file:

| Loại | Đuôi file | Nội dung |
|------|-----------|----------|
| **Mẫu báo cáo** | .docx | Chứa heading, hướng dẫn dạng "Lấy file X, vẽ Biểu đồ N, phân tích..." |
| **Dữ liệu** | .xlsx | Chứa dữ liệu World Bank: cột country, year, mã chỉ số (NY.GDP...) |

**Quy tắc nhận diện:**
- File .docx → mẫu báo cáo (chỉ có 1 file)
- File .xlsx → dữ liệu (có thể 1 hoặc nhiều file, đánh số 1, 2, 3, 4...)
- Người dùng KHÔNG cần tải file Python — code đã có sẵn trong skill

---

### BƯỚC 2 — ĐỌC VÀ PHÂN TÍCH FILE MẪU BÁO CÁO

#### 2.1. Unpack và đọc nội dung

```bash
python /mnt/skills/public/docx/scripts/office/unpack.py \
  /mnt/user-data/uploads/<mẫu>.docx /home/claude/unpacked_template/

pandoc /mnt/user-data/uploads/<mẫu>.docx -t plain --wrap=none
```

#### 2.2. Xác định từ nội dung mẫu

Phân tích text để tìm:

1. **Cấu trúc heading**: 1., 1.1., 1.2.1., 2., 2.1., ... → mục lục báo cáo
2. **Hướng dẫn phân tích**: dạng "Lấy file X.xlsx, vẽ Biểu đồ N, phân tích..."
3. **Mapping file → biểu đồ**: "Lấy file 1.xlsx" → dùng file 1.xlsx cho biểu đồ đó
4. **Mã chỉ số WB**: NY.GDP.MKTP.KD.ZG, FP.CPI.TOTL.ZG, NE.TRD.GNFS.ZS...
5. **Quốc gia**: USA, CHN, GBR, VNM, WLD...
6. **Số biểu đồ & bảng**: Biểu đồ 1-9, Bảng 1-3...
7. **Yêu cầu dự báo**: mô hình, biến đầu vào/ra, tỷ lệ train/test, mục tiêu chính sách

#### 2.3. Xác định formatting gốc từ XML

Từ file đã unpack, ghi nhận:
- Font: thường Times New Roman
- Size body: thường 13pt (size=26 half-points)
- Page: A4 (11906 × 16838 DXA)
- Margins: thường 1440 DXA mỗi bên (= 1 inch)
- Alignment body: justified (both)
- Heading: bold, cùng font và size với body
- Title: bold, size lớn hơn (thường 16pt = size 32)

**Content width** = page width − left margin − right margin
Ví dụ: 11906 − 1440 − 1440 = 9026 DXA

---

### BƯỚC 3 — ĐỌC FILE EXCEL DỮ LIỆU

```python
import pandas as pd

# Đọc từng file
df = pd.read_excel('/mnt/user-data/uploads/<file>.xlsx')

# Xử lý merged cells (country bị NaN từ dòng 2 trở đi)
df['country'] = df['country'].ffill()

# Chuyển year sang số, sắp xếp
df['year'] = pd.to_numeric(df['year'])
df.sort_values(['country','year'], inplace=True)

# Xử lý NaN (theo code tham chiếu: fillna(mean))
df = df.fillna(df.mean(numeric_only=True))
```

**Cấu trúc Excel điển hình từ World Bank:**
```
| country        | year | NY.GDP.MKTP.KD.ZG | NY.GDP.PCAP.KD.ZG | ... |
|----------------|------|---------------------|--------------------|-----|
| China          | 2000 | 8.586               | 7.734              | ... |
|                | 2001 | 8.312               | 7.528              | ... |  ← country rỗng
| United Kingdom | 2000 | 3.885               | 3.444              | ... |
```

---

### BƯỚC 4 — ĐỌC CODE PYTHON THAM CHIẾU

```bash
cat <skill_dir>/reference_code.py
```

Trích xuất từ code tham chiếu:

| Thành phần | Giá trị trong code gốc | Điều chỉnh cho báo cáo |
|------------|----------------------|------------------------|
| `figsize` | (10,5) | → (5.9, 3.3) cho vừa A4 |
| `dpi` | 200 | Giữ nguyên 200 |
| `fontsize title` | 18 | → 10 |
| `fontsize label` | 15 | → 9 |
| `fontsize tick` | default | → 7 |
| `markersize` | default | → 3-4 |
| `marker` | 'o' | Giữ nguyên (bổ sung 's','^' cho multi-line) |
| `color` | '#ff7f50' | Giữ nguyên style gốc |
| `grid` | linestyle='--', linewidth=0.5 | → linewidth=0.3, alpha=0.7 |
| `plt.show()` | hiển thị | → `plt.savefig('chartN.png', dpi=200, bbox_inches='tight')` |
| `test_size` | 0.1 | → theo mẫu báo cáo (thường 0.2 = 80:20) |
| `random_state` | 15 | → 42 hoặc theo mẫu báo cáo |
| Thuật toán | LinearRegression | Giữ nguyên |
| Đánh giá | MSE, RMSE, MAE | Giữ nguyên |

**Nguyên tắc quan trọng:**
- Mẫu báo cáo là **CHỦ** (quyết định biến nào, mô hình nào, tỷ lệ nào)
- Code tham chiếu là **THAM CHIẾU** (style biểu đồ, thuật toán, cách đánh giá)
- Nếu mẫu yêu cầu biến khác code gốc → dùng biến theo mẫu
- Nếu mẫu yêu cầu phân tích mà code gốc không có → Claude tự viết

---

### BƯỚC 5 — VẼ BIỂU ĐỒ & CHẠY PHÂN TÍCH

#### 5.1. Setup

```python
import warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np, pandas as pd, seaborn as sns

plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False
```

#### 5.2. Kích thước chuẩn cho A4

```python
W, H, DPI = 5.9, 3.3, 200      # figsize cho biểu đồ thường
W_CORR, H_CORR = 5.2, 3.5       # figsize cho heatmap tương quan

# Khi chèn vào docx (ImageRun transformation):
IMG_W_PX = round(5.5 * 72)  # = 396 pixels
IMG_H_PX = round(3.1 * 72)  # = 223 pixels
```

#### 5.3. Mẫu vẽ từng loại biểu đồ

**Line chart (1 quốc gia):**
```python
fig, ax = plt.subplots(figsize=(W, H), dpi=DPI)
ax.plot(years, values, marker='o', markersize=4, color='#1f77b4', linewidth=1.5)
ax.axhline(y=0, color='gray', linewidth=0.5, linestyle='--')
ax.set_title('Biểu đồ N: ...', fontweight='bold', fontsize=10)
ax.set_xlabel('Năm', fontsize=9)
ax.set_ylabel('% tăng trưởng', fontsize=9)
ax.set_xticks(years[::2])
ax.tick_params(labelsize=7)
ax.grid(True, linestyle='--', linewidth=0.3, alpha=0.7)
# Annotate min/max
for idx in [np.argmin(vals), np.argmax(vals)]:
    ax.annotate(f'{vals[idx]:.1f}%', (yrs[idx], vals[idx]),
                textcoords="offset points", xytext=(0,8), fontsize=6, ha='center')
plt.tight_layout()
plt.savefig('chartN.png', dpi=DPI, bbox_inches='tight')
plt.close()
```

**Multi-line chart (nhiều quốc gia):**
```python
fig, ax = plt.subplots(figsize=(W, H), dpi=DPI)
colors = {'China': ('#d62728','s'), 'United Kingdom': ('#2ca02c','^'), 'United States': ('#1f77b4','o')}
for country, (color, mkr) in colors.items():
    sub = df[df['country']==country].sort_values('year')
    ax.plot(sub['year'], sub[col], marker=mkr, markersize=3, label=label, linewidth=1.2, color=color)
ax.legend(fontsize=7, loc='upper right')
# ... title, xlabel, ylabel, grid, save giống trên
```

**Bar + Line combo:**
```python
ax.bar(years, values, color='#ff7f50', width=0.7, edgecolor='white', linewidth=0.3)
ax.plot(years, values, marker='o', markersize=3, color='#8B0000', linewidth=1)
```

**Area chart:**
```python
ax.fill_between(years, values, alpha=0.3, color='#2ecc71')
ax.plot(years, values, marker='o', markersize=3, color='#27ae60', linewidth=1.5)
```

**Heatmap tương quan:**
```python
fig, ax = plt.subplots(figsize=(W_CORR, H_CORR), dpi=DPI)
sns.heatmap(df.corr().round(2), annot=True, cmap='RdYlBu_r', center=0, fmt='.2f',
            linewidths=0.5, ax=ax, annot_kws={'size': 9}, cbar_kws={'shrink': 0.8})
```

#### 5.4. Thống kê & dự báo

```python
# Thống kê mô tả (tham chiếu: df.describe())
desc = df.describe().round(2)

# Linear Regression (tham chiếu: LinearRegression + train_test_split)
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Biến theo MẪU BÁO CÁO (không phải code gốc)
y = df['GDP']
X1 = df[['GDPP','CPI']]            # Mô hình 1: theo mẫu
X2 = df[['GDPP','CPI','TRADE','SAVING']]  # Mô hình 2: theo mẫu

# Tỷ lệ theo MẪU BÁO CÁO
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Đánh giá (tham chiếu: MSE, RMSE, MAE)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)

# Dự báo chính sách (tham chiếu: model.predict([[...]])
y_forecast = model.predict([[GDPP_target, CPI_target, TRADE_target, SAVING_target]])
```

#### 5.5. Viết phân tích văn bản

Cho **mỗi biểu đồ/bảng**, Claude viết phân tích với cấu trúc:

1. **Mô tả xu hướng**: tăng/giảm/ổn định, các giai đoạn chính
2. **Điểm ngoặt**: năm biến động lớn (khủng hoảng 2008, COVID-19 2020...)
3. **Nguyên nhân**: chính sách tiền tệ/tài khóa, sự kiện quốc tế, cải cách
4. **So sánh** (nếu nhiều quốc gia): điểm tương đồng và khác biệt
5. **Nhận định**: ý nghĩa chính sách, triển vọng

**QUAN TRỌNG:** Dùng số liệu CỤ THỂ từ dữ liệu thực, giọng văn học thuật, tham chiếu
sự kiện kinh tế có thật (WTO 2007, CPTPP, EVFTA, khủng hoảng 2008, COVID-19...).

---

### BƯỚC 6 — TẠO FILE BÁO CÁO DOCX

#### 6.1. Tạo bằng docx-js

```bash
npm install -g docx  # nếu chưa cài
```

#### 6.2. Giữ nguyên formatting mẫu gốc

Dựa trên XML phân tích ở Bước 2, tạo document với ĐÚNG:
- **Font**: Times New Roman (hoặc font trong mẫu)
- **Size body**: 13pt = size 26 half-points (hoặc theo mẫu)
- **Page**: A4 = width 11906, height 16838 DXA
- **Margins**: theo mẫu (thường 1440 mỗi bên)
- **Alignment body**: JUSTIFIED
- **Heading**: bold, cùng font/size body, alignment justified
- **Title**: bold, size 16pt = 32, alignment center
- **Line spacing**: 1.3 = line 312

#### 6.3. Cấu trúc document

```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
        AlignmentType, BorderStyle, WidthType, ShadingType,
        VerticalAlign, PageBreak } = require('docx');
const fs = require('fs');

const doc = new Document({
    styles: {
        default: { document: { run: { font: "Times New Roman", size: 26 } } }
    },
    sections: [{
        properties: {
            page: {
                size: { width: 11906, height: 16838 },
                margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
            }
        },
        children: [
            // 1. Header table (logo + quốc hiệu) — copy từ mẫu
            // 2. Title (BÁO CÁO KINH TẾ VĨ MÔ...)
            // 3. Các phần 1, 2, 3 với heading, biểu đồ, bảng, phân tích
        ]
    }]
});
```

#### 6.4. Chèn biểu đồ

```javascript
// Ảnh căn giữa, kích thước vừa A4
new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
    children: [new ImageRun({
        data: fs.readFileSync('chartN.png'),
        transformation: { width: Math.round(5.5*72), height: Math.round(3.1*72) },
        type: 'png'
    })]
})
// Caption nghiêng, nhỏ hơn
new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 120 },
    children: [new TextRun({
        text: "Nguồn: World Bank", font: "Times New Roman", size: 22, italics: true
    })]
})
```

#### 6.5. Tạo bảng

```javascript
const bdr = {style: BorderStyle.SINGLE, size: 1, color: "000000"};
const borders = {top: bdr, bottom: bdr, left: bdr, right: bdr};

// Header row: shading fill "D5E8F0", bold, size 22 (11pt), center
// Data rows: size 22, center (trừ cột đầu left)
// Width: dùng WidthType.DXA, tổng = content width
// Cell margins: {top:40, bottom:40, left:80, right:80}
```

#### 6.6. Logo từ template

```javascript
// Copy logo khi unpack template
const logo = fs.readFileSync('/home/claude/unpacked_template/word/media/image1.png');
// Chèn vào header table: transformation {width:90, height:75}
```

#### 6.7. Header table (logo + quốc hiệu)

```javascript
// Table 2 cột không viền: [logo | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM]
// Cột 1: logo ~ 2500 DXA
// Cột 2: 3 dòng centered (quốc hiệu, khẩu hiệu, ngày tháng)
// Borders: NONE
```

---

### BƯỚC 7 — VALIDATE & XUẤT FILE

```bash
# Validate
python /mnt/skills/public/docx/scripts/office/validate.py /home/claude/output.docx

# Xuất
cp /home/claude/output.docx /mnt/user-data/outputs/<tên_báo_cáo>.docx
```

Dùng `present_files` để gửi file cho người dùng.

---

## XỬ LÝ CÁC TÌNH HUỐNG ĐẶC BIỆT

### Mẫu báo cáo yêu cầu biến khác code gốc
- Code gốc dùng: M2, INF, R, TRADE
- Mẫu có thể yêu cầu: GDPP, CPI, SAVING
- → **Luôn theo mẫu báo cáo**, chỉ lấy style/thuật toán từ code gốc

### Mẫu yêu cầu phân tích không có trong code gốc
- Claude tự viết code bổ sung (ví dụ: biểu đồ area, bar+line combo)
- Giữ style nhất quán với code gốc (color palette, grid style)

### Excel có merged cells / NaN
```python
df['country'] = df['country'].ffill()  # Forward-fill country
df = df.fillna(df.mean(numeric_only=True))  # Điền mean cho NaN số
```

### Tên quốc gia trong Excel khác mẫu
- Excel: "China", "United States", "United Kingdom", "Viet Nam"
- Mẫu viết: CHN, USA, GBR, VNM
- → Map tự động khi lọc dữ liệu

### Dự báo chính sách
- Đọc kỹ mục tiêu trong mẫu (GDPP=5%, CPI=2%, TRADE=170%, SAVING=70%)
- Input array ĐÚNG THỨ TỰ biến của mô hình
- Dự báo bằng CẢ HAI mô hình, chọn mô hình tốt nhất
- Phân tích: nếu mục tiêu xa thực tế lịch sử → cảnh báo

### PageBreak khi nội dung dài
- Thêm PageBreak trước phần 2 (Kinh tế VN) và phần 3 (Dự báo)
```javascript
new Paragraph({ children: [new PageBreak()] })
```

---

## CHECKLIST TRƯỚC KHI XUẤT

- [ ] Đã đọc /mnt/skills/public/docx/SKILL.md
- [ ] Đã đọc <skill_dir>/reference_code.py
- [ ] Đã unpack và phân tích file mẫu .docx
- [ ] Đã đọc tất cả file Excel, ffill country, sort year, fillna
- [ ] Biểu đồ kích thước (5.9×3.3), dpi 200, savefig với bbox_inches='tight'
- [ ] Bảng thống kê mô tả có đủ 8 dòng (count, mean, std, min, 25%, 50%, 75%, max)
- [ ] Ma trận tương quan đã vẽ heatmap
- [ ] Model train/test theo tỷ lệ mẫu yêu cầu
- [ ] MSE, RMSE, MAE đã tính cho cả 2 mô hình
- [ ] Dự báo chính sách đã chạy với giá trị mục tiêu từ mẫu
- [ ] Phân tích văn bản cho MỖI biểu đồ và bảng (dùng số liệu thực)
- [ ] Font: Times New Roman, size body 26 (13pt), caption/bảng 22 (11pt)
- [ ] Page: A4, margins theo mẫu gốc
- [ ] Logo chèn đúng vị trí header
- [ ] Ngày tháng trên header = ngày hiện tại
- [ ] File validate PASSED
- [ ] File đã copy sang /mnt/user-data/outputs/
- [ ] Đã gọi present_files
